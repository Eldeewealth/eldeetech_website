#css Config
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
